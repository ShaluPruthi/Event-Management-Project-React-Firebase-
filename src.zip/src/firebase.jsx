// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB5rWsNI2dlbu28xFWhFWLHMtvaV_dBHj4",
  authDomain: "event-30dec.firebaseapp.com",
  projectId: "event-30dec",
  storageBucket: "event-30dec.firebasestorage.app",
  messagingSenderId: "451443419678",
  appId: "1:451443419678:web:da823b35a4b80519829c0f",
  measurementId: "G-97JT5SJLHM"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);