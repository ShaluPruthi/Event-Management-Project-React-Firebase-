import "./App.css";
import Hero from "./components/Hero";
import Login from "./components/Login";
import Services from "./components/Services";
import Navigation from "./components/Navigation";
import About from "./components/About";
import Contact from "./components/Contact";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Category from "./components/Category";
import CreateEvent from "./components/CreateEvent";
import Social from "./components/Social"


const App = () => {

  return (
    <Router>
      <Navigation/>
      <Routes>
      <Route path="/" element={<Hero/>}/>
        <Route path="/Home" element={<Hero/>}/>
        <Route path="/services" element={<Services/>} />
        <Route path="/about" element={<About/>}/>
        <Route path="/contact" element={<Contact/>}/>
        <Route path="/login" element={<Login/>} />
        <Route path="/Category" element={<Category/>} />
        <Route path="/CreateEvent" element={<CreateEvent/>} />
      </Routes>
      <Social/>
    </Router>
  );
};

export default App;