
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const Login = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState('email,password');
 

  const getUserData = (e) => {
    const { name, value } = e.target;
    setUser({...user, [name]: value,
    });
  };


  const handleLogin = async(event) => {
    event.preventDefault();

    const{email,password} = user;

    if(email && password){

    const response = await fetch(
      'https://event-30dec-default-rtdb.firebaseio.com/login.json',
      {
        method : "POST",
        headers : {
          "Content-Type" : "application/json",
        },
        body: JSON.stringify({
          email,
          password,
        })
      })
      if(response){
        setUser({
          email,
          password,
      })
        console.log('Logging in with:', { email, password });
        navigate('/'); // Redirect to the home page after login
      } else { 
        alert('Failed to log in'); 

      }
    } 
      else { 
        alert("Please enter your email and password");
      }
};



  return (
    <div className="login-page">
      <div className="login-image">
        <img src="./images/login.jpg" alt="Login Illustration" />
      </div>
      <div className="login-form-container">
        <h2>LogIn</h2>
        <form onSubmit={handleLogin} method='POST'>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name='email'
              value={user.email}
              onChange={getUserData}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name='password'
              value={user.password}
              onChange={getUserData}
              required
            />
          </div>
          <button type="submit" className="login-button">Login</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
