import "../Styles/Services.css"

const Services = () => {

  return (
    <div className="services-us">
      <section className="service-section">
      <div className="content">
      <h1>Our Services</h1>
      <p>At <b>Team Event</b>, we offer a wide range of services to simplify event planning and execution. 
        From intimate gatherings to large-scale events, 
        our platform is designed to meet your needs every step of the way.</p>
      </div>
      </section>

      <section className="service-section">
        <div className="content">
        <h1>Event Planning</h1>
        <p>Let us help you turn your ideas into reality. Our event planning tools and expert support 
          ensure that every detail is accounted for, from concept to execution.

          <br/># Customized event templates.
          <br/># Seamless collaboration with vendors and teams.
          <br/># Easy-to-use checklists to keep you on track.</p>
          </div>
          <div className="service-image">
            <img src="./images/plan.jpg"/>
            <img src="./images/plan2.avif"/>
          </div>
      </section>

      <section className="service-section">
        <div className="content">
        <h1>Venue Management</h1>
        <p>Find the perfect venue for your event with our comprehensive database 
          and advanced search tools.

          <br/># Detailed venue listings with photos and reviews.
          <br/># Location-based recommendations.
          <br/># Booking and payment integration for convenience.</p>
          </div>
          <div className="service-image">
            <img src="./images/venue.avif" alt="Venue Management"/>
            <img src="./images/location.jpg" alt="Venue Management"/>
          </div>
      </section>

      <section className="service-section">
        <div className="content">
        <h1>Virtual and Hybrid Events</h1>
        <p>Embrace the future of event management with tools 
          for online and hybrid events.

          <br/># Seamless live-streaming integrations.
          <br/># Interactive features like Q&A, polls, and chat rooms.
          <br/># Breakout room options for small group discussions.</p>
          </div>
          <div className="service-image">
            <img src="./images/discuss.avif" alt="VH events"/>
            <img src="./images/chat.avif" alt="VH events"/>
          </div>
      </section>

      <section className="service-section">
        <div className="content">
        <h1>Vendor Coordination</h1>
        <p>Connect with trusted vendors to ensure every element of your event is flawless.

          <br/># Verified vendor profiles for catering, decor, entertainment, and more.
          <br/># Easy communication and contract management.
          <br/># Access to reviews and recommendations.</p>
          </div>
          <div className="service-image">
            <img src="./images/event.jpg" alt="VH events"/>
            <img src="./images/event1.webp" alt="VH events"/>
          </div>
      </section>
    </div>
  )
}

export default Services
