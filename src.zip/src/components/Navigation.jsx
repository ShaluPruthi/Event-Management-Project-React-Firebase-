import { NavLink } from "react-router-dom";

const Navigation = () => {
    return(
      <nav>
        <div className="logo">
          <img src="./images/brand-logo.png"/>
        </div>
        <ul className="justify-content-center">
          <li>
            <NavLink to="/" style={{textDecoration:'none'}}>Home</NavLink>
            </li> 
          <li>
          <NavLink to="/services" style={{textDecoration:'none'}}>Services</NavLink>
          </li>
          <li>
          <NavLink to="/About" style={{textDecoration:'none'}}>About</NavLink>
          </li>
          <li>
          <NavLink to="/contact" style={{textDecoration:'none'}}>Contact</NavLink>
          </li>
          <NavLink to="/login" style={{textDecoration:'none'}}>
          <button>Login</button>
        </NavLink>
        </ul>
      </nav>
    );
};



export default Navigation;