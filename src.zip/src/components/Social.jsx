

const Social = () => {
const Style ={
            padding :"20px 10px" ,
            textAlign :"center",
            display:"flex",
            felxWrap:"wrap",
            justifyContent:"space-around",
            
    };
const Footer={
            flex:1,
            minWidth: 200,
            margin:"10 0",

};

  return (
    <div style={Style}>
    <div style={Footer}>
      <h3>Contact Us:</h3><br/>
      <p>E-mail: <a href="https://mail.google.com/mail/u/0/#inbox?compose=new">support@TeamEvent.com</a> </p>
      <p>Phone: +123-456-7890</p>
    </div>
      <div>
        <h3>Follow Us:</h3>
        <a href="https://www.x.com/"></a>
      </div>
    </div>

    
  )
}

export default Social
