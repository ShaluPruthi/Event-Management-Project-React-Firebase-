import { useNavigate } from 'react-router-dom';

const Hero = () => {
    const navigate = useNavigate();
    return (
        <main className="hero">
            <div>
                <h1 style={{textAlign:'left'}}>YOUR LIFE DESERVES THE BEST EVENT</h1>
                <p>
                    IF YOU'RE NOT INVITED TO THE PARTY, THROW YOUR OWN.
                </p>
                <div className="hero-button">
                    <button onClick={() => navigate('/CreateEvent')}>Create Event</button>
                    <button onClick={() => navigate('/Category')}>Category</button>                    
                </div>
            </div>
            <div className="hero-image">
                <img src="/images/Main.png" alt="Main" />
            </div>
        </main>
    );
}

export default Hero;
