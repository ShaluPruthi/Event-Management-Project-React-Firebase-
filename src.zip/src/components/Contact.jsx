import { useState } from 'react';
import './Contact.css';

const Contact = () => {
  const [user, setUser] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const getUserData = (e) => {
    const { name, value } = e.target;
    setUser((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const postData = async(event) => {
    event.preventDefault();

    const{name,email,phone,message} = user;
    // for validation
    if(name && email && phone && message){

      // to store data in firebase
    const res = await fetch(
      'https://event-30dec-default-rtdb.firebaseio.com/Contact.json',
      {
        method : "POST",
        headers : {
          "Content-Type" : "application/json",
        },
        body:JSON.stringify({
          name,
          email,
          phone,
          message,
        })
      }
    );
    // sends an alert message if data stored successfully
    if (res) {
      setUser({
        name: "",
        email: "",
        phone: "",
        message: "",
      });
      alert("Data Stored Successfully");
    }
  }
    else{
      alert("Please fill all the Data")
    }
  };

  return (
    <div className="contact-container">
      <div className="contact-details">
        <h2>Contact Us</h2>
        <p>Feel free to reach out to us with any questions or feedback!</p>
        
        <form className="contact-form" method='POST'>
          <label>
            Name:
            <input
              type="text"
              placeholder='Enter your name'
              name="name"
              value={user.name}
              onChange={getUserData}
              autoComplete='off'
              required
            />
          </label>
          <label>
            Email:
            <input
              type="email"
              name="email"
              placeholder='Enter your email'
              value={user.email}
              onChange={getUserData}
              autoComplete='off'
              required
            />
          </label>
          <label>
            Phone:
            <input
              type="number"
              name="phone"
              placeholder='Enter your phone number'
              value={user.phone}
              onChange={getUserData}
              autoComplete='off'
              required
            />
          </label>
          <label>
            Message:
            <textarea
              name="message"
              placeholder='Write your message here...'
              value={user.message}
              onChange={getUserData}
              autoComplete='off'
              required
            ></textarea>
          </label>
          <button type="submit" className="submit-button" onClick={postData}>Submit</button>
        </form>
      </div>

      <div className="contact-image">
        <img src="./images/contact-image.jpg" alt="Contact Us" />
      </div>
    </div>
  );
};

export default Contact;
