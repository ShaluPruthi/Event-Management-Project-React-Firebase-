import '../Styles/Category.css';

const Category = () => {
  const myStyle = {
    color: "red",
    alignItem: "center",
    marginLeft: "47%",
    fontWeight: "bold",
    fontSize: 20
  };

  const corporateImages = [
    './images/corporate-events.jpg',
    './images/Corporate-Events 1.jpg',
    './images/Corporate-Events 2.jpg',
    './images/Corporate-Events 3.jpg'
  ];

  const socialImages = [
    './images/social-event 4.jpg',
    './images/social-event 5.jpg',
    './images/social-event 2.jpg',
    './images/social-event 3.jpg'
  ];

  const culturalImages = [
    './images/cultural.webp',
    './images/cultural 1.jpg',
    './images/cultural 2.jpg',
    './images/cultural 3.jpg'
  ];

  const entertainmentImages = [
    './images/social-event.jpg',
    './images/social-event 1.jpg',
    './images/entertainment.jpeg',
    './images/entertainment 1.jpeg'
  ];

  const educationalImages = [
    './images/educational.jpg',
    './images/educational 1.jpg',
    './images/educational 2.jpg',
    './images/educational 3.jpg'
  ];

  const interestImages = [
    './images/interest.jpg',
    './images/interest 1.jpg',
    './images/interest 2.jpg',
    './images/interest 3.jpg'
  ];


  return (
    <div className='begin'>
      <h1 style={{color:"Purple", fontWeight:"normal", display:"flex",alignItems:"center", justifyContent:"center"}}>
        Explore, Plan, Create: Categories That Bring Every Event to Life!
      </h1>
      <h2>Corporate Events</h2>
      <p style={myStyle}>Price : 20,000</p>
      <div className='image-container'>
        {corporateImages.map((src, index) => (
          <img key={index} className="image" src={src} alt={`Corporate Event ${index + 1}`} />
        ))}
      </div>

      <h2>Social Events</h2>
      <p style={myStyle}>Price : 30,000</p>
      <div className='image-container'>
        {socialImages.map((src, index) => (
          <img key={index} className="image" src={src} alt={`Social Event ${index + 1}`} />
        ))}
      </div>
      

      <h2>Cultural Events</h2>
      <p style={myStyle}>Price : 46,000</p>
      <div className='image-container'>
        {culturalImages.map((src, index) => (
          <img key={index} className="image" src={src} alt={`Cultural Event ${index + 1}`} />
        ))}
      </div>
      
      <h2>Entertainment Events</h2>
      <p style={myStyle}>Price : 50,000</p>
      <div className='image-container'>
        {entertainmentImages.map((src, index) => (
          <img key={index} className="image" src={src} alt={`Entertainment Event ${index + 1}`} />
        ))}
      </div>
      

      <h2>Educational Events</h2>
      <p style={myStyle}>Price : 15,000</p>
      <div className='image-container'>
        {educationalImages.map((src, index) => (
          <img key={index} className="image" src={src} alt={`Educational Event ${index + 1}`} />
        ))}
      </div>
      
      <h2>Special Interest Events</h2>
      <p style={myStyle}>Price : 25,000</p>
      <div className='image-container'>
        {interestImages.map((src, index) => (
          <img key={index} className="image" src={src} alt={`Special Events ${index + 1}`} />
        ))}
      </div>
      
    </div>
  );
};

export default Category;
