import './About.css';

const About = () => {
    return (
        <div className="about-us">
          <section className='about-section'>
            <div className='about-image'>
              <img src='./images/About.avif'></img>
            </div>
            <div className='about-content'>
              <h2>About Us</h2>
              <p>
              Welcome to <b>Team Event</b>, your ultimate platform for planning and managing unforgettable events. 
              Whether you're organizing a grand wedding, a corporate seminar, or a casual gathering, we provide 
              the tools and expertise to turn your vision into reality.
              </p>
            </div>
          </section>
            <section className="about-section">
                <div className="about-content">
                  
                    <h2>Our Mission</h2>
                    <p>
                    Our mission is to simplify event planning by offering a seamless and intuitive platform 
                    that caters to all your event management needs.<br/>
                    From concept to execution, we strive to create experiences that leave lasting impressions.
                    </p>
                </div>
                <div className="about-image">
                    <img src="./images/About.jpg" alt="Our Founding" /> 
                </div>
            </section>

            <section className="about-section">
                <div className="about-image">
                    <img src="./images/About1.jpg" alt="Early Growth" /> 
                </div>
                <div className="about-content">
                    <h2>What we Offer</h2>
                    <p>
                    <b>Comprehensive Event Planning Tools:</b> Streamline your process with features like scheduling, ticketing, and real-time updates.<br/>
                    <b>Customizable Solutions:</b> Tailor your events with personalized themes, categories, and branding.<br/>
                    <b>Collaboration Made Easy:</b> Work closely with vendors, attendees, and teams using our integrated communication tools.<br/>
                    <b>Analytics and Insights:</b> Track event performance and attendee engagement to ensure continuous improvement.<br/>
                    </p>
                </div>
            </section>

            <section className="about-section">
                <div className="about-content">
                    <h2>Why Choose Us?</h2>
                    <p>
                    At <b>Team Event</b>, we believe that every event deserves meticulous attention to detail and a touch of creativity. 
                    We bring together cutting-edge technology, user-friendly design, and expert support to help you plan events that are as unique as you are.
                    </p>
                </div>
                <div className="about-image">
                    <img src="./images/About2.jpg" alt="Why Choose Us" /> 
                </div>
            </section>

            <section className="about-section">
                <div className="about-content">
                    <h2>Join Our Community</h2>
                    <p>
                    Join a growing community of event organizers, businesses, 
                    and individuals who trust us to make their events extraordinary. 
                    Whether you're a seasoned professional or planning your first event, Team Event is here to guide you every step of the way.

                    Let’s make your next event a success—because every moment deserves to be celebrated!
                    </p>
                </div>
                <div className="about-image">
                    <img src="./images/About3.jpg" alt="join our community" /> 
                </div>
            </section>
        </div>
    );
};

export default About;
