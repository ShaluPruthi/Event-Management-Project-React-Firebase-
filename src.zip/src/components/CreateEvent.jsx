import { useState } from 'react';
import Modal from 'react-modal';
import { collection, addDoc } from 'firebase/firestore';
import { db } from './firebase'; // Adjust the import path according to your project structure
import '../Styles/CreateEvent.css';
import { useNavigate } from 'react-router-dom';

Modal.setAppElement('#root');

const CreateEvent = () => {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [ticketType, setTicketType] = useState('');
  const [contact, setContact] = useState('');
  const [email, setEmail] = useState('');
  const [visible, setVisible] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validateForm()) {
      await addEvent();
      setVisible(true);
      navigate({
        pathname: '/schedule',
        state: { date, time, location }
      });
    }
  };

  const validateForm = () => {
    const contactRegex = /^[0-9]{10}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!contactRegex.test(contact)) {
      alert('Please enter a valid 10-digit contact number');
      return false;
    }
    if (!emailRegex.test(email)) {
      alert('Please enter a valid email address');
      return false;
    }
    return true;
  };

  const addEvent = async () => {
    await addDoc(collection(db, 'events'), {
      date,
      time,
      location,
      ticketType,
      contact,
      email,
      description: 'New Event',
    });
  };

  return (
    <div className='create'>
      <h3 className='top'>Tell Us About Your Event Preferences</h3>
      <p className='sal'>Turning Moments into Memories, One Event at a Time!</p>

      <div className='start'>
        <form onSubmit={handleSubmit}>
          <label className='event'>Event Type</label>
          <select className="form-select">
            <option selected>Select the event type</option>
            <option value="1">Corporate</option>
            <option value="2">Social</option>
            <option value="3">Educational</option>
            <option value="4">Entertainment</option>
            <option value="5">Special Interest</option>
            <option value="6">Cultural</option>
          </select>

          <label className='event'>Date</label>
          <input
            className="form-select"
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
          />

          <label className='event'>Time</label>
          <input
            className="form-select"
            type="time"
            value={time}
            onChange={e => setTime(e.target.value)}
          />

          <label className='event'>Location</label>
          <input
            className="form-select"
            type="text"
            value={location}
            onChange={e => setLocation(e.target.value)}
          />

          <label className='event'>Ticket Type</label>
          <select
            className="form-select"
            value={ticketType}
            onChange={e => setTicketType(e.target.value)}>
            <option selected>Select the ticket type</option>
            <option value="Free">Free</option>
            <option value="Paid">Paid</option>
            <option value="VIP">VIP</option>
          </select>

          <label className='event'>Event Description</label>
          <textarea />

          <label className='event'>Name of Attendee</label>
          <input className="form-select" type="text" />

          <label className='event'>Contact</label>
          <input
            className="form-select"
            type="text"
            value={contact}
            onChange={e => setContact(e.target.value)}
          />

          <label className='event'>Email id</label>
          <input
            className="form-select"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />

          <button type="submit">Submit</button>
        </form>
      </div>

      <Modal
        isOpen={visible}
        onRequestClose={() => setVisible(false)}
        className="modal-content"
      >
        <h2>Your Event Is Successfully Created!!</h2>
        <button onClick={() => setVisible(false)}>Ok</button>
      </Modal>
    </div>
  );
};

export default CreateEvent;
